#!/bin/bash

set -e

echo "📦 Creating gitlab-operator namespace..."
kubectl create namespace gitlab-operator --dry-run=client -o yaml | kubectl apply -f -

echo "🧩 Deploying PostgreSQL..."
kubectl apply -f postgres/postgres-deployment.yaml
kubectl apply -f postgres/postgres-service.yaml

echo "📦 Deploying GitLab Operator..."
kubectl apply -f operator.yaml

echo "🎛️ Waiting for GitLab Operator to be ready..."
kubectl wait deployment gitlab-operator-controller-manager -n gitlab-operator --for=condition=Available --timeout=180s

echo "🧪 Deploying GitLab CR (Custom Resource)..."
kubectl apply -f gitlab-cr.yaml

echo "✅ GitLab Operator and GitLab instance deployed!"
